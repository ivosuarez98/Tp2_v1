#ifndef Casillero_H_

#define Casillero_H_

class Casillero
{
private:
    char celda;
public:
    void setCelda(char celda);
    char getCelda();
};


#endif
