#include "Casillero.h"
/*
Casillero::Casillero()
{
	this->celda='_'
}

Casillero::~Casillero()
{
}
*/
void Casillero::setCelda(char celda)
{
    this->celda =celda;
}

char Casillero::getCelda(){
	return this->celda;
}
