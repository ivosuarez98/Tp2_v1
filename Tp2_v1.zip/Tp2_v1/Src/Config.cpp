/*
 * Config.cpp
 *
 *  Created on: 07/10/2022
 *      Author: algo2
 */

#include "Config.h"

Config::Config() {
	// TODO Auto-generated constructor stub

}

Config::~Config() {
	// TODO Auto-generated destructor stub
}

